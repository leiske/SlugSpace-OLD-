
Useful types
------------

.. toctree::
   :maxdepth: 2

   /docs/type/useful/objectdescriptor
   /docs/type/useful/generalizedtime
   /docs/type/useful/utctime
